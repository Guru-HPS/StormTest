Action()
{
	 web_set_sockets_option("SSL_VERSION","2&3");
	 web_set_max_html_param_len("30024");
	
	 web_set_sockets_option ("IGNORE_PREMATURE_SHUTDOWN", "1");
	 
	 web_set_sockets_option("INITIAL_BASIC_AUTH","1");
	 
	
	lr_start_transaction("HPS_SLP_CHC_Standalone_API");
	
	web_add_auto_header("User-Agent", "Apache-HttpClient/4.1.1 (java 1.5)");
	web_add_header("SOAPAction", "http://healthplan.com/enrollment/applicationinfo/v1/getMemberApplications");
	web_add_header("Content-Type", "text/xml; charset=utf8");
	
	    
	web_add_header("X-IBM-Client-Secret", "R3jW3nS7mN0eR1sC0qM6mK2dL5qV4gO7vA7eU8lX2lI6gC0tX4");
	 
    web_add_header("X-IBM-Client-Id", "3e6d2f55-ebae-4672-9c6b-2dce23378346");

	web_reg_find("Text=1848_028", "SaveCount=Available_Documents", LAST);    
	
	web_custom_request("CHC_API",
		"URL=https://webapi2.emdeon.com/glue/WebAPIServer",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Mode=HTML",
		"EncType=text/xml;charset=UTF-8",
		"Body=<soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:_web=\"http://tempuri.org/_WebAPICalls\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\"> \r\n"
		" <soapenv:Header/> \r\n"
		" <soapenv:Body> \r\n"
		" <_web:RetrieveClaimInformation soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"> \r\n"
		" <arg0 xsi:type=\"type:_WebAPIInputs\" xmlns:type=\"http://tempuri.org/type\"> \r\n"
		" <AuthToken xsi:type=\"xsd:string\">LY1iEMa2ZPoCGnJHAqs7M6hEcywdVmH4SIo3IZqLlN0mX6kT0tEDZ10~</AuthToken> \r\n"
		"  <ClientId_ClientKey xsi:type=\"xsd:string\">1848_028</ClientId_ClientKey>v\r\n"
		" <RecipientType xsi:type=\"xsd:string\">I</RecipientType> \r\n"
		"  <RecipientId xsi:type=\"xsd:string\">{p_Cim}</RecipientId> \r\n"
		" <SearchType xsi:type=\"xsd:string\">CLAIM_NBR</SearchType> \r\n"
		"  <FormatCodeList xsi:type=\"xsd:string\">A1T</FormatCodeList> \r\n"
		" <ClaimNumberList xsi:type=\"xsd:string\">{p_Case}</ClaimNumberList> \r\n"
		"  </arg0> \r\n"
		"   </_web:RetrieveClaimInformation> \r\n"
		"  </soapenv:Body> \r\n"
		"</soapenv:Envelope> \r\n",
		LAST);
    
    if(atoi(lr_eval_string("{Available_Documents}"))>0)
	{
		
		lr_end_transaction("HPS_SLP_CHC_Standalone_API",LR_PASS);
		lr_output_message(lr_eval_string("{Available_Documents}"));
		
	}
	else
	{
		lr_error_message("Member Communication is not loaded for Cim%s, Case%s", lr_eval_string("{P_case}"), lr_eval_string("{P_CimNum}"));
		
		lr_end_transaction("HPS_SLP_CHC_Standalone_API",LR_FAIL);
		//lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE,LR_FAIL);
	}
	

	//lr_end_transaction("HPS_SLP_CHC_Standalone_API", LR_AUTO);

	
	return 0;
}
